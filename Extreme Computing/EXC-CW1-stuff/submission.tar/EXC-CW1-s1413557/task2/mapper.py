#!/usr/bin/python

import sys

#Same stuff in task 1
for line in sys.stdin:

	print("{0}".format(line.strip().lower()))
