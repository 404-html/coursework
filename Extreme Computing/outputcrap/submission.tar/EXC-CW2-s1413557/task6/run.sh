cat /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part3/webLarge.txt \
  | python ~/Desktop/EXC-CW2-s1413557/task6/bloom.py -n 1897987
