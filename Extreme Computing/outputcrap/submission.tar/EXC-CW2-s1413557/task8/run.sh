cat /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part4/queriesLarge.txt \
	| ~/Desktop/EXC-CW2-s1413557/task8/lossycount.py
