cat /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part3/webLarge.txt \
 | ~/Desktop/EXC-CW2-s1413557/task5/reservoir.py
